/**
 * Pediamum® Lifestyle & Nutrition Companion
 * Exact 1:1 Functional Logic & Food Database Replica
 * Transcribed from https://4173-iurxymm1ho0ezcwxtwdg1-60b3e9d1.sg2.manus.computer/calculator
 * and official pediamum.com/calc/
 */

// Official Food Nutrition Database transcribed from Pediamum Nutritional Guide
const FoodDatabase = {
  nuts: {
    name: "Nuts",
    nameAr: "المكسرات",
    defaultMeasure: "100g",
    measures: [
      { id: "100g", label: "100 gm or Ml", labelAr: "100 جم أو مل", factor: 1.0 },
      { id: "oz", label: "Ounce", labelAr: "أونصة", factor: 0.2835 },
      { id: "cup", label: "Cup (250 ml)", labelAr: "كوب (250 مل)", factor: 2.5 }
    ],
    items: [
      { name: "Almonds", nameAr: "لوز", val: 546 },
      { name: "Walnuts", nameAr: "عين جمل", val: 523 },
      { name: "Cashew", nameAr: "كاجو", val: 155 },
      { name: "Pistachios", nameAr: "فستق", val: 691 },
      { name: "Peanuts", nameAr: "فول سوداني", val: 828 },
      { name: "Pine Nuts", nameAr: "صنوبر", val: 909 },
      { name: "Sunflower Seeds", nameAr: "بذور عباد الشمس", val: 818 },
      { name: "Pumpkin Seeds", nameAr: "بذور اليقطين", val: 721 },
      { name: "Chia Seeds", nameAr: "بذور الشيا", val: 136 },
      { name: "Coconut", nameAr: "جوز هند", val: 1405 },
      { name: "Hazelnut", nameAr: "بندق", val: 471 },
      { name: "Brazil Nuts", nameAr: "جوز برازيلي", val: 872 },
      { name: "Macadamia Nuts", nameAr: "ماكاديميا", val: 962 }
    ]
  },

  vegetables: {
    name: "Vegetables",
    nameAr: "الخضروات",
    defaultMeasure: "100g",
    measures: [
      { id: "100g", label: "100 gm or Ml", labelAr: "100 جم أو مل", factor: 1.0 }
    ],
    items: [
      { name: "Spinach", nameAr: "سبانخ", val: 23 },
      { name: "Tomato", nameAr: "طماطم", val: 18 },
      { name: "Cucumber", nameAr: "خيار", val: 16 },
      { name: "Broccoli", nameAr: "بروكلي", val: 34 },
      { name: "Carrot", nameAr: "جزر", val: 41 },
      { name: "Zucchini", nameAr: "كوسة", val: 17 },
      { name: "Sweet Potato", nameAr: "بطاطا حلوة", val: 86 },
      { name: "Potato", nameAr: "بطاطس", val: 77 },
      { name: "Bell Pepper", nameAr: "فلفل رومي", val: 20 },
      { name: "Lettuce", nameAr: "خس", val: 15 },
      { name: "Mushrooms", nameAr: "مشروم", val: 22 },
      { name: "Eggplant", nameAr: "باذنجان", val: 25 },
      { name: "Cauliflower", nameAr: "قرنبيط", val: 25 },
      { name: "Green Beans", nameAr: "فاصوليا خضراء", val: 31 }
    ]
  },

  dairy: {
    name: "Dairy",
    nameAr: "منتجات الألبان",
    defaultMeasure: "100g",
    measures: [
      { id: "100g", label: "100 gm or Ml", labelAr: "100 جم أو مل", factor: 1.0 },
      { id: "oz", label: "Ounce", labelAr: "أونصة", factor: 0.28 },
      { id: "cup", label: "Cup (250 ml)", labelAr: "كوب (250 مل)", factor: 2.5 }
    ],
    items: [
      { name: "Pediamum® Maternal Milk (Reconstituted)", nameAr: "حليب Pediamum® للأمومة", val: 71 },
      { name: "Whole Milk", nameAr: "حليب كامل الدسم", val: 61 },
      { name: "Semi-skimmed Milk", nameAr: "حليب نصف دسم", val: 50 },
      { name: "Skim Milk", nameAr: "حليب خالي الدسم", val: 35 },
      { name: "Plain Yogurt", nameAr: "زبادي طبيعي", val: 61 },
      { name: "Cottage Cheese", nameAr: "جبن قريش", val: 98 },
      { name: "Lactose-free Milk", nameAr: "حليب خالي اللاكتوز", val: 52 },
      { name: "Powdered Milk", nameAr: "حليب مجفف", val: 496 }
    ]
  },

  rice: {
    name: "Rice",
    nameAr: "الأرز",
    defaultMeasure: "cup",
    measures: [
      { id: "cup", label: "Per Cooked Cup (240g)", labelAr: "لكل كوب مطبوخ", factor: 1.0 }
    ],
    items: [
      { name: "Regular White Rice", nameAr: "أرز أبيض عادي", val: 204 },
      { name: "Regular Brown Rice", nameAr: "أرز بني صحي", val: 215 },
      { name: "Short-Grain White Rice", nameAr: "أرز أبيض قصير الحبة", val: 242 },
      { name: "Rice with Vegetables", nameAr: "أرز بالخضار", val: 170 },
      { name: "Rice with Beans", nameAr: "أرز بالفاصوليا", val: 392 },
      { name: "Rice Pilaf", nameAr: "أرز بيلاف", val: 258 }
    ]
  },

  protein: {
    name: "Animal Protein & Cheese",
    nameAr: "البروتين الحيواني والأجبان",
    defaultMeasure: "100g",
    measures: [
      { id: "100g", label: "100 gm (Default)", labelAr: "100 جم (افتراضي)", factor: 1.0 }
    ],
    items: [
      { name: "Chicken Breast", nameAr: "صدور دجاج", val: 172 },
      { name: "Roast Beef", nameAr: "لحم بقري مشوي", val: 140 },
      { name: "Turkey Breast", nameAr: "صدر ديك رومي", val: 135 },
      { name: "T-Bone Steak", nameAr: "ستيك تي بون", val: 202 },
      { name: "Ground Beef", nameAr: "لحم مفروم", val: 246 },
      { name: "Cheddar Cheese", nameAr: "جبن شيدر", val: 403 },
      { name: "Mozzarella Cheese", nameAr: "جبن موتزاريلا", val: 280 },
      { name: "Feta Cheese", nameAr: "جبن فيتا", val: 264 },
      { name: "Swiss Cheese", nameAr: "جبن سويسري", val: 380 },
      { name: "Halloumi Cheese", nameAr: "جبن حلوم", val: 321 }
    ]
  },

  legumes: {
    name: "Legumes",
    nameAr: "البقوليات",
    defaultMeasure: "100g",
    measures: [
      { id: "100g", label: "100 gm or Ml", labelAr: "100 جم أو مل", factor: 1.0 },
      { id: "oz", label: "Ounce", labelAr: "أونصة", factor: 0.2835 },
      { id: "cup", label: "Cup (250 ml)", labelAr: "كوب (250 مل)", factor: 2.5 }
    ],
    items: [
      { name: "Lentils", nameAr: "عدس أصفر وبني", val: 353 },
      { name: "Chickpeas", nameAr: "حمص", val: 364 },
      { name: "White Beans", nameAr: "فاصوليا بيضاء", val: 336 },
      { name: "Kidney Beans", nameAr: "فاصوليا حمراء", val: 337 },
      { name: "Soybeans", nameAr: "فول الصويا", val: 147 },
      { name: "Peas", nameAr: "بسلة", val: 42 }
    ]
  },

  oil: {
    name: "Oil",
    nameAr: "الزيوت والدهون",
    defaultMeasure: "100g",
    measures: [
      { id: "100g", label: "100 gm or Ml", labelAr: "100 جم أو مل", factor: 1.0 },
      { id: "oz", label: "Ounce", labelAr: "أونصة", factor: 0.2835 },
      { id: "cup", label: "Cup (250 ml)", labelAr: "كوب (250 مل)", factor: 2.5 }
    ],
    items: [
      { name: "Olive Oil", nameAr: "زيت زيتون", val: 884 },
      { name: "Sunflower Oil", nameAr: "زيت عباد الشمس", val: 884 },
      { name: "Corn Oil", nameAr: "زيت الذرة", val: 800 },
      { name: "Sesame Oil", nameAr: "زيت السمسم", val: 884 },
      { name: "Real Butter", nameAr: "زبدة طبيعية", val: 720 },
      { name: "Avocado Oil", nameAr: "زيت الأفوكادو", val: 857 }
    ]
  },

  seafood: {
    name: "Seafood",
    nameAr: "المأكولات البحرية",
    defaultMeasure: "84g",
    measures: [
      { id: "84g", label: "Serving (84 gm)", labelAr: "حصة (84 جم)", factor: 1.0 }
    ],
    items: [
      { name: "Salmon", nameAr: "سلمون", val: 130 },
      { name: "Tilapia", nameAr: "بلطي", val: 110 },
      { name: "Cod", nameAr: "سمك القد", val: 90 },
      { name: "Shrimp", nameAr: "جمبري", val: 100 },
      { name: "Tuna", nameAr: "تونة", val: 130 },
      { name: "Rainbow Trout", nameAr: "تراوت", val: 140 }
    ]
  },

  fruits: {
    name: "Fruits",
    nameAr: "الفواكه",
    defaultMeasure: "serving",
    measures: [
      { id: "serving", label: "1 Standard Serving", labelAr: "1 حصة قياسية", factor: 1.0 }
    ],
    items: [
      { name: "Apple (1 large, 242g)", nameAr: "تفاح كبير (242 جم)", val: 130 },
      { name: "Banana (1 medium, 126g)", nameAr: "موز متوسط (126 جم)", val: 110 },
      { name: "Avocado (1/5 medium, 30g)", nameAr: "أفوكادو (30 جم)", val: 50 },
      { name: "Orange (1 medium, 154g)", nameAr: "برتقال متوسط (154 جم)", val: 80 },
      { name: "Strawberries (8 medium, 147g)", nameAr: "فراولة (8 حبات، 147 جم)", val: 50 },
      { name: "Grapes (3/4 cup, 126g)", nameAr: "عنب (3/4 كوب، 126 جم)", val: 90 },
      { name: "Peach (1 medium, 147g)", nameAr: "خوخ متوسط (147 جم)", val: 60 },
      { name: "Watermelon (2 cups diced, 280g)", nameAr: "بطيخ (كوبان مقطع، 280 جم)", val: 80 }
    ]
  }
};

// Global State
const CompanionState = {
  currentTab: 'calculate', // 'home' | 'explore' | 'calculate' | 'profile'
  lang: 'en',              // 'en' | 'ar'
  selectedCategories: new Set(),
  categorySelections: {},  // { categoryKey: { foodIndex: 0, measureId: '', qty: 1 } }
  waterTracker: {
    date: '',
    cups: 0,
    targetCups: 12
  },
  profile: {
    name: '',
    age: '28',
    topic: 'pregnant',      // 'planning' | 'pregnant' | 'breastfeeding'
    trimester: 2,           // 1 | 2 | 3
    weight: '',
    height: ''
  },
  notifications: [],
  dismissedAlertIds: new Set(),
  savedMeals: []
};


// Translations Dictionary
const AppDictionary = {
  en: {
    appName: "pediamum®",
    appTagline: "Women’s lifestyle & nutrition",
    langBtn: "العربية",
    
    // Bottom Tabs
    tabHome: "Home",
    tabExplore: "Explore",
    tabCalculate: "Calculate",
    tabProfile: "Profile",

    // Home View
    homeForWho: "For women aged 20–50",
    homeHeroTitle: "A little clarity for your next step.",
    homeHeroDesc: "Explore recipes, food-calorie information and Pediamum® product details, at your own pace. This app is educational—not a substitute for professional care.",
    btnExplore: "Explore",
    btnCalculator: "Calculator",
    homeProductTag: "From the Pediamum website",
    homeProductTitle: "Product information, simply presented",
    homeProductDesc: "See the published product overview, ingredient names and preparation guidance.",
    btnViewPediamum: "View Pediamum®",
    homeRecipeTitle: "Recipe photographs from the booklet",
    homeRecipeDesc: "Tap a photo to enlarge it, or use the button to open the full recipe.",
    btnBrowseRecipes: "Browse recipes",
    homeShortcutsTitle: "Your shortcuts",
    shortcutRecipes: "Ready-to-make recipes",
    shortcutOnboarding: "Onboarding preview",
    homeTopicTag: "A place to continue",
    homeTopicTitle: "Maternal nutrition",
    homeTopicDesc: "A source-labelled overview topic based on your saved context.",
    btnOpenTopic: "Open this topic",
    homeRecentlyViewed: "Recently viewed",
    homeReadingListEmpty: "Your reading list will appear here as you explore.",
    homeDisclaimer: "Brand colors are prototype approximations sampled from available Pediamum packaging imagery. Official hexadecimal brand codes were not published on the reviewed pages.",

    // Explore View
    exploreForWho: "Explore · women aged 20–50",
    exploreHeroTitle: "Find what you need, at your own pace.",
    exploreHeroDesc: "Browse recipes, food-calorie information, Pediamum® product details and educational topics. Source labels distinguish booklet and website content.",
    exploreTopicsHeader: "Explore by topic",
    topic1Title: "Pediamum® product hub",
    topic1Desc: "Overview, ingredients and website preparation guidance.",
    topic1Tag: "Official product information",
    topic2Title: "Ready-to-make recipes",
    topic2Desc: "Three recipes from the supplied booklet.",
    topic2Tag: "Supplied Pediamum booklet",
    topic3Title: "Caloric Content calculator",
    topic3Desc: "Select foods and quantities in the official Pediamum Nutritional Guide.",
    topic3Tag: "Nutritional Guide",
    topic4Title: "Maternal nutrition",
    topic4Desc: "A topic collection for pregnancy and lactation reading.",
    topic4Tag: "Educational topic",
    topic5Title: "The first 1,000 days",
    topic5Desc: "What the Pediamum website says about early-life nutrition.",
    topic5Tag: "Source-attributed",
    topic6Title: "Breastfeeding support",
    topic6Desc: "The reference site’s stated position on breastfeeding.",
    topic6Tag: "Source-attributed",
    exploreHealthNoteTitle: "A note about health information",
    exploreHealthNoteDesc: "Topics in this prototype are not personal medical guidance. For questions about your health or nutrition, speak with a qualified healthcare professional.",

    // Calculator View
    calcTag: "Meal calculator · source-matched",
    calcTitle: "Caloric Content",
    calcSubtitle: "Choose whatever you want to add in your meal",
    calcNotice1: "The calculator uses the food values and serving units shown on Pediamum’s official Nutritional Guide. It does not calculate personal daily needs.",
    calcNotice2: "Food values, portion labels and category formulas are transcribed from the official calculator. The total is for selected foods only—not a personal daily calorie requirement or nutrition recommendation.",
    calcBookletCardTitle: "Photo from the supplied Pediamum booklet",
    calcBookletCardDesc: "Tap the picture to enlarge it, or browse the recipe and its source-listed ingredients.",
    calcChooseCategories: "Choose food categories",
    calcChooseSub: "Choose one or more categories, then add foods and set a quantity.",
    calcTotalTag: "Source values · food calories only",
    calcTotalHeading: "Total calories for all categories",
    calcUnitLabel: "calories",
    calcZeroHint: "Add foods to calculate a total.",
    btnSaveMeal: "Save meal record",
    btnResetCalc: "Reset calculator",
    btnSourceRef: "Source reference",
    calcBottomNotice: "Food-calorie values transcribed from the Pediamum website calculator. They are not an individualized daily energy target or medical recommendation.",

    // Profile View
    profileTag: "Your space",
    profileTitle: "Profile & activity",
    profileSubtitle: "This companion is intended for women aged 20–50. Your optional profile and demo history stay on this device.",
    profileDetailsTitle: "Profile details",
    profileNameLabel: "Name (optional)",
    profileNamePlaceholder: "What should we call you?",
    profileAgeLabel: "Age (years)",
    profileAgePlaceholder: "20–50",
    profileAgeHint: "For the intended audience: women aged 20–50.",
    profileTopicsFollow: "Topics I follow",
    topicPlanning: "Planning",
    topicPregnant: "Pregnant",
    topicBreastfeeding: "Breastfeeding",
    btnSaveProfile: "Save profile",
    profileSavedMealsTitle: "Saved meals",
    btnOpenCalc: "Open calculator",
    profileNoSavedMeals: "No saved meals yet. Meal history is optional and remains on this device.",
    profileRecentlyViewed: "Recently viewed",
    profilePreferencesNotices: "Preferences & notices",
    btnSettingsNotice: "Settings and privacy notice",
    btnClearDemo: "Clear local demo data",
    profileNoticeDisclaimer: "Health and nutrition information in this prototype is educational and is not a diagnosis, treatment plan or substitute for a qualified professional.",
    profileNoticeStorage: "Local data is stored using device AsyncStorage. Review privacy, retention and data protection requirements before production use."
  },

  ar: {
    appName: "Pediamum®",
    appTagline: "أسلوب حياة وتغذية المرأة",
    langBtn: "English",

    // Bottom Tabs
    tabHome: "الرئيسية",
    tabExplore: "استكشاف",
    tabCalculate: "الحاسبة",
    tabProfile: "الملف",

    // Home View
    homeForWho: "للنساء من سن 20 إلى 50 عاماً",
    homeHeroTitle: "وضوح لخطوتك القادمة.",
    homeHeroDesc: "استكشفي الوصفات، ومعلومات السعرات الحرارية، وتفاصيل منتج Pediamum® براحتك وبأسلوبك الخاص. هذا التطبيق تعليمي وليس بديلاً عن الرعاية الطبية.",
    btnExplore: "استكشاف",
    btnCalculator: "الحاسبة",
    homeProductTag: "من موقع Pediamum الرسمي",
    homeProductTitle: "معلومات المنتج بأسلوب واضح وبسيط",
    homeProductDesc: "اطلعي على المكونات، والفوائد الغذائية، وطريقة التحضير المعتمدة.",
    btnViewPediamum: "عرض Pediamum®",
    homeRecipeTitle: "صور الوصفات من كتيب Pediamum",
    homeRecipeDesc: "اضغطي على الصورة لتكبيرها، أو افتحي الوصفة الكاملة ومكوناتها.",
    btnBrowseRecipes: "تصفح الوصفات",
    homeShortcutsTitle: "اختصاراتك",
    shortcutRecipes: "وصفات جاهزة للتحضير",
    shortcutOnboarding: "مقدمة التطبيق",
    homeTopicTag: "موضوع للمتابعة",
    homeTopicTitle: "تغذية الأمومة",
    homeTopicDesc: "دليل موثق وشامل لصحة وتغذية الحامل والمرضع.",
    btnOpenTopic: "فتح هذا الموضوع",
    homeRecentlyViewed: "شوهد مؤخراً",
    homeReadingListEmpty: "ستظهر قائمة قراءاتك هنا كلما تصفحتِ محتوى التطبيق.",
    homeDisclaimer: "ألوان الهوية هنا مستوحاة بدقة من عبوات Pediamum الرسمية وموقع الشركة المعتمد.",

    // Explore View
    exploreForWho: "استكشاف · للنساء من 20 إلى 50 عاماً",
    exploreHeroTitle: "اعثري على ما تحتاجينه براحتك.",
    exploreHeroDesc: "تصفحي الوصفات، حاسبة السعرات، معلومات منتج Pediamum® والمواضيع التعليمية الموثقة.",
    exploreTopicsHeader: "استكشاف حسب الموضوع",
    topic1Title: "مركز منتج Pediamum®",
    topic1Desc: "نظرة عامة، المكونات، وطريقة التحضير المعتمدة.",
    topic1Tag: "معلومات المنتج الرسمية",
    topic2Title: "وصفات جاهزة للتحضير",
    topic2Desc: "ثلاث وصفات صحية ولذيذة من كتيب Pediamum.",
    topic2Tag: "كتيب Pediamum المعتمد",
    topic3Title: "حاسبة السعرات الحرارية للأطعمة",
    topic3Desc: "اختاري الأطعمة والكميات في الدليل الغذائي الرسمي لPediamum.",
    topic3Tag: "الدليل الغذائي",
    topic4Title: "تغذية الأمومة",
    topic4Desc: "مجموعة مواضيع تثقيفية عن الحمل والرضاعة الطبيعية.",
    topic4Tag: "موضوع تعليمي",
    topic5Title: "الألف يوم الأولى",
    topic5Desc: "ما ينص عليه موقع Pediamum بشأن تغذية بدايات الحياة والنمو.",
    topic5Tag: "موثق من المصدر",
    topic6Title: "دعم الرضاعة الطبيعية",
    topic6Desc: "دعم توصيات منظمة الصحة العالمية بشأن الرضاعة الطبيعية.",
    topic6Tag: "موثق من المصدر",
    exploreHealthNoteTitle: "تنبيه طبي",
    exploreHealthNoteDesc: "المواضيع في هذا التطبيق تثقيفية وليست إرشادات طبية شخصية. يرجى استشارة الطبيب المعالج لأي استفسار.",

    // Calculator View
    calcTag: "حاسبة الوجبات · مطابقة للمصدر",
    calcTitle: "محتوى السعرات الحرارية",
    calcSubtitle: "اختاري ما ترغبين في إضافته إلى وجبتك",
    calcNotice1: "تستخدم الحاسبة قيم الأطعمة ووحدات الحصص الموضحة في دليل Pediamum الغذائي الرسمي. ولا تحسب الاحتياج اليومي الفردي.",
    calcNotice2: "قيم السعرات، وتسميات الحصص، ومعادلات الفئات منقولة حرفياً من الحاسبة الرسمية. الإجمالي مخصص للأطعمة المختارة فقط.",
    calcBookletCardTitle: "صورة من كتيب Pediamum المعتمد",
    calcBookletCardDesc: "اضغطي على الصورة لتكبيرها، أو استعرضي مكونات وصفة سموذي الخوخ والأفوكادو.",
    calcChooseCategories: "اختاري فئات الأطعمة",
    calcChooseSub: "اختاري فئة أو أكثر، ثم حددي الأطعمة والكميات المطلوبة.",
    calcTotalTag: "قيم المصدر · سعرات الأطعمة فقط",
    calcTotalHeading: "إجمالي السعرات لجميع الفئات",
    calcUnitLabel: "سعرة حرارية",
    calcZeroHint: "أضيفي أطعمة لحساب الإجمالي.",
    btnSaveMeal: "حفظ سجل الوجبة",
    btnResetCalc: "إعادة ضبط الحاسبة",
    btnSourceRef: "المرجع والمصدر",
    calcBottomNotice: "قيم السعرات الحرارية منقولة من حاسبة موقع Pediamum الرسمي، وليست تشخيصاً أو توصية طبية بديلة.",

    // Profile View
    profileTag: "مساحتك الخاصة",
    profileTitle: "الملف الشخصي والنشاط",
    profileSubtitle: "هذا التطبيق مخصص للنساء من عمر 20 إلى 50 عاماً. يظل ملفك وسجلك محفوظاً على هذا الجهاز فقط.",
    profileDetailsTitle: "بيانات الملف",
    profileNameLabel: "الاسم (اختياري)",
    profileNamePlaceholder: "ما هو اسمك المفضل؟",
    profileAgeLabel: "العمر (سنوات)",
    profileAgePlaceholder: "20–50",
    profileAgeHint: "للجمهور المستهدف: النساء من سن 20 إلى 50 عاماً.",
    profileTopicsFollow: "المواضيع التي أتابعها",
    topicPlanning: "التخطيط للحمل",
    topicPregnant: "الحمل",
    topicBreastfeeding: "الرضاعة الطبيعية",
    btnSaveProfile: "حفظ الملف",
    profileSavedMealsTitle: "الوجبات المحفوظة",
    btnOpenCalc: "فتح الحاسبة",
    profileNoSavedMeals: "لا توجد وجبات محفوظة بعد. سجل الوجبات اختياري ويظل على هذا الجهاز.",
    profileRecentlyViewed: "شوهد مؤخراً",
    profilePreferencesNotices: "التفضيلات والإشعارات",
    btnSettingsNotice: "إعدادات وسياسة الخصوصية",
    btnClearDemo: "مسح البيانات المحلية",
    profileNoticeDisclaimer: "معلومات الصحة والتغذية في هذا التطبيق تعليمية وليست خطة علاج أو تشخيص طبي.",
    profileNoticeStorage: "يتم تخزين البيانات محلياً على جهازك بواسطة تقنية التخزين المحلي الآمن."
  }
};

// Switch Tab Navigation
function switchTab(tabId) {
  CompanionState.currentTab = tabId;
  
  document.querySelectorAll('.tab-item').forEach(el => {
    if (el.getAttribute('data-tab') === tabId) {
      el.classList.add('active');
    } else {
      el.classList.remove('active');
    }
  });

  document.querySelectorAll('.page-view').forEach(view => {
    if (view.id === `view-${tabId}`) {
      view.classList.add('active');
    } else {
      view.classList.remove('active');
    }
  });

  // Scroll to top
  const mainScroll = document.getElementById('mainScrollView');
  if (mainScroll) mainScroll.scrollTop = 0;
}

// Language Switcher (EN <-> AR)
function toggleLanguage() {
  CompanionState.lang = CompanionState.lang === 'en' ? 'ar' : 'en';
  applyLanguage(CompanionState.lang);
}

function applyLanguage(lang) {
  const dict = AppDictionary[lang];
  const root = document.documentElement;

  if (lang === 'ar') {
    root.setAttribute('dir', 'rtl');
    root.setAttribute('lang', 'ar');
  } else {
    root.setAttribute('dir', 'ltr');
    root.setAttribute('lang', 'en');
  }

  // Update dynamic texts
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (dict[key]) {
      el.textContent = dict[key];
    }
  });

  // Update placeholders
  document.querySelectorAll('[data-i18n-ph]').forEach(el => {
    const key = el.getAttribute('data-i18n-ph');
    if (dict[key]) {
      el.placeholder = dict[key];
    }
  });

  // Update category labels and panels
  renderCategoryPills();
  renderActiveCategoryPanels();
  renderSavedMealsList();
  renderWaterTracker();
  renderPersonalizedAlerts();
  calculateBmiGuidance();
}


// Render Category Checkbox Pills
function renderCategoryPills() {
  const container = document.getElementById('categoryPillsContainer');
  if (!container) return;

  const isAr = CompanionState.lang === 'ar';
  container.innerHTML = '';

  Object.keys(FoodDatabase).forEach(catKey => {
    const cat = FoodDatabase[catKey];
    const isSelected = CompanionState.selectedCategories.has(catKey);

    const pill = document.createElement('div');
    pill.className = `category-pill ${isSelected ? 'selected' : ''}`;
    pill.setAttribute('role', 'checkbox');
    pill.setAttribute('aria-checked', isSelected ? 'true' : 'false');
    const label = isAr ? cat.nameAr : cat.name;
    pill.innerHTML = `${isSelected ? '<span style="font-size:12px; font-weight:800;">✓</span> ' : ''}${label}`;

    pill.onclick = () => toggleCategory(catKey);
    container.appendChild(pill);
  });
}

// Toggle a Food Category
function toggleCategory(catKey) {
  if (CompanionState.selectedCategories.has(catKey)) {
    CompanionState.selectedCategories.delete(catKey);
    delete CompanionState.categorySelections[catKey];
  } else {
    CompanionState.selectedCategories.add(catKey);
    const cat = FoodDatabase[catKey];
    CompanionState.categorySelections[catKey] = {
      foodIndex: 0,
      measureId: cat.measures[0].id,
      qty: 1
    };
  }

  renderCategoryPills();
  renderActiveCategoryPanels();
  calculateTotalCalories();
}

// Render Active Category Panels
function renderActiveCategoryPanels() {
  const container = document.getElementById('activeCategoryPanelsContainer');
  if (!container) return;

  const isAr = CompanionState.lang === 'ar';
  container.innerHTML = '';

  CompanionState.selectedCategories.forEach(catKey => {
    const cat = FoodDatabase[catKey];
    const selection = CompanionState.categorySelections[catKey];
    if (!selection) return;

    const panel = document.createElement('div');
    panel.className = 'category-panel';

    // Panel Header
    const header = document.createElement('div');
    header.className = 'panel-header';
    header.innerHTML = `
      <h4>${isAr ? cat.nameAr : cat.name}</h4>
      <span class="panel-subtotal" id="subtotal-${catKey}">0 ${isAr ? 'سعرة' : 'kcal'}</span>
    `;
    panel.appendChild(header);

    // Food Select Dropdown
    const select = document.createElement('select');
    select.className = 'food-select';
    cat.items.forEach((item, idx) => {
      const opt = document.createElement('option');
      opt.value = idx;
      opt.textContent = `${isAr ? item.nameAr : item.name} (${item.val} kcal)`;
      if (idx === selection.foodIndex) opt.selected = true;
      select.appendChild(opt);
    });

    select.onchange = (e) => {
      selection.foodIndex = parseInt(e.target.value, 10);
      calculateTotalCalories();
    };
    panel.appendChild(select);

    // Measures Units
    if (cat.measures.length > 1) {
      const unitsWrap = document.createElement('div');
      unitsWrap.className = 'measure-units-row';
      cat.measures.forEach(m => {
        const chip = document.createElement('div');
        chip.className = `unit-radio-chip ${m.id === selection.measureId ? 'selected' : ''}`;
        chip.textContent = isAr ? m.labelAr : m.label;
        chip.onclick = () => {
          selection.measureId = m.id;
          renderActiveCategoryPanels();
          calculateTotalCalories();
        };
        unitsWrap.appendChild(chip);
      });
      panel.appendChild(unitsWrap);
    }

    // Stepper Quantity Row
    const stepperRow = document.createElement('div');
    stepperRow.className = 'stepper-row';
    stepperRow.innerHTML = `
      <span class="stepper-label">${isAr ? 'عدد الحصص / المقادير:' : 'Number of Scoops / Portions:'}</span>
      <div class="stepper-control">
        <button type="button" class="stepper-btn" onclick="stepCategoryQty('${catKey}', -1)">−</button>
        <span class="stepper-value" id="qty-${catKey}">${selection.qty}</span>
        <button type="button" class="stepper-btn" onclick="stepCategoryQty('${catKey}', 1)">+</button>
      </div>
    `;
    panel.appendChild(stepperRow);

    container.appendChild(panel);
  });
}

// Adjust Stepper Quantity
function stepCategoryQty(catKey, delta) {
  const selection = CompanionState.categorySelections[catKey];
  if (!selection) return;

  selection.qty = Math.max(1, selection.qty + delta);
  const qtyEl = document.getElementById(`qty-${catKey}`);
  if (qtyEl) qtyEl.textContent = selection.qty;

  calculateTotalCalories();
}

// Calculate Total Calories
function calculateTotalCalories() {
  let total = 0;

  CompanionState.selectedCategories.forEach(catKey => {
    const cat = FoodDatabase[catKey];
    const selection = CompanionState.categorySelections[catKey];
    if (!selection) return;

    const food = cat.items[selection.foodIndex] || cat.items[0];
    const measure = cat.measures.find(m => m.id === selection.measureId) || cat.measures[0];
    const factor = measure ? measure.factor : 1.0;

    const subtotal = Math.round(food.val * factor * selection.qty);
    total += subtotal;

    const subEl = document.getElementById(`subtotal-${catKey}`);
    const isAr = CompanionState.lang === 'ar';
    if (subEl) subEl.textContent = `${subtotal.toLocaleString()} ${isAr ? 'سعرة' : 'kcal'}`;
  });

  // Update Total Display
  const totalNumEl = document.getElementById('totalCaloriesNumber');
  const totalHintEl = document.getElementById('totalCaloriesHint');
  const btnSave = document.getElementById('btnSaveMeal');
  const btnReset = document.getElementById('btnResetCalc');

  if (totalNumEl) totalNumEl.textContent = total.toLocaleString();

  if (total > 0) {
    if (totalHintEl) totalHintEl.textContent = CompanionState.lang === 'ar' ? 'تم الحساب بنجاح لجميع الفئات المختارة.' : 'Total calculated from official source values.';
    if (btnSave) {
      btnSave.classList.remove('btn-disabled');
      btnSave.removeAttribute('disabled');
    }
    if (btnReset) {
      btnReset.classList.remove('btn-disabled');
      btnReset.removeAttribute('disabled');
    }
  } else {
    if (totalHintEl) totalHintEl.textContent = CompanionState.lang === 'ar' ? 'أضيفي أطعمة لحساب الإجمالي.' : 'Add foods to calculate a total.';
    if (btnSave) {
      btnSave.classList.add('btn-disabled');
      btnSave.setAttribute('disabled', 'true');
    }
    if (btnReset) {
      btnReset.classList.add('btn-disabled');
      btnReset.setAttribute('disabled', 'true');
    }
  }
}

// Reset Calculator
function resetCalculator() {
  CompanionState.selectedCategories.clear();
  CompanionState.categorySelections = {};
  renderCategoryPills();
  renderActiveCategoryPanels();
  calculateTotalCalories();
}

// Save Meal Record to Local Storage
function saveMealRecord() {
  const total = parseInt(document.getElementById('totalCaloriesNumber').textContent.replace(/,/g, ''), 10) || 0;
  if (total <= 0) return;

  const isAr = CompanionState.lang === 'ar';
  const items = [];
  CompanionState.selectedCategories.forEach(catKey => {
    const cat = FoodDatabase[catKey];
    const sel = CompanionState.categorySelections[catKey];
    if (sel) {
      const food = cat.items[sel.foodIndex];
      items.push(`${isAr ? food.nameAr : food.name} (${sel.qty}x)`);
    }
  });

  const record = {
    id: Date.now(),
    calories: total,
    itemsText: items.join(', '),
    date: new Date().toLocaleDateString(isAr ? 'ar-EG' : 'en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  };

  CompanionState.savedMeals.unshift(record);
  try {
    localStorage.setItem('pediamum_saved_meals', JSON.stringify(CompanionState.savedMeals));
  } catch(e) {}

  alert(isAr ? 'تم حفظ سجل الوجبة بنجاح في ملفك!' : 'Meal record saved successfully to your profile!');
  renderSavedMealsList();
}

// Render Saved Meals in Profile View
function renderSavedMealsList() {
  const container = document.getElementById('savedMealsContainer');
  if (!container) return;

  const isAr = CompanionState.lang === 'ar';

  if (!CompanionState.savedMeals.length) {
    container.innerHTML = `
      <div class="card-box" style="background-color: var(--color-surface);">
        <p style="color: var(--color-muted); font-size: 13px;">
          ${isAr ? 'لا توجد وجبات محفوظة بعد. سجل الوجبات اختياري ويظل على هذا الجهاز.' : 'No saved meals yet. Meal history is optional and remains on this device.'}
        </p>
      </div>
    `;
    return;
  }

  container.innerHTML = '';
  CompanionState.savedMeals.forEach(meal => {
    const card = document.createElement('div');
    card.className = 'card-box';
    card.style.display = 'flex';
    card.style.flexDirection = 'row';
    card.style.justifyContent = 'space-between';
    card.style.alignItems = 'center';

    card.innerHTML = `
      <div style="flex:1;">
        <div style="font-weight:700; color:var(--color-primary); font-size:16px;">
          ${meal.calories.toLocaleString()} ${isAr ? 'سعرة' : 'calories'}
        </div>
        <div style="font-size:12px; color:var(--color-foreground); margin:2px 0;">
          ${meal.itemsText}
        </div>
        <div style="font-size:11px; color:var(--color-muted);">
          ${meal.date}
        </div>
      </div>
      <button onclick="deleteMealRecord(${meal.id})" style="border:none; background:transparent; color:#EF4444; font-size:18px; cursor:pointer;" title="Delete">
        ✕
      </button>
    `;
    container.appendChild(card);
  });
}

// Delete a Saved Meal Record
function deleteMealRecord(id) {
  CompanionState.savedMeals = CompanionState.savedMeals.filter(m => m.id !== id);
  try {
    localStorage.setItem('pediamum_saved_meals', JSON.stringify(CompanionState.savedMeals));
  } catch(e) {}
  renderSavedMealsList();
}

// ===================================================================
// INTERACTIVE WATER CONSUMPTION TRACKER ENGINE
// ===================================================================

function getTodayDateString() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

// Calculate target water based on official Pediamum Arabic Booklet recommendations
function calculateWaterTarget() {
  const stage = CompanionState.profile.topic;
  if (stage === 'breastfeeding') return 16; // ~4.0 Liters (~16 cups of 250ml) - Golden rule: water with every feed
  if (stage === 'planning') return 10;      // ~2.5 Liters (~10 cups) - preconception cellular hydration
  return 12;                                // ~3.0 Liters (~12 cups) for pregnant women to eliminate sodium & avoid edema
}

function initWaterTracker() {
  const today = getTodayDateString();
  CompanionState.waterTracker.targetCups = calculateWaterTarget();
  try {
    const saved = localStorage.getItem('pediamum_water');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed.date === today) {
        CompanionState.waterTracker.cups = parsed.cups || 0;
      } else {
        // New calendar day: start fresh
        CompanionState.waterTracker.cups = 0;
      }
    }
  } catch(e) {}
  CompanionState.waterTracker.date = today;
  saveWaterTracker();
  renderWaterTracker();
}

function saveWaterTracker() {
  try {
    localStorage.setItem('pediamum_water', JSON.stringify({
      date: CompanionState.waterTracker.date,
      cups: CompanionState.waterTracker.cups,
      targetCups: CompanionState.waterTracker.targetCups
    }));
  } catch(e) {}
}

function logWaterCup(delta) {
  const newCups = Math.max(0, CompanionState.waterTracker.cups + delta);
  CompanionState.waterTracker.cups = newCups;
  saveWaterTracker();
  renderWaterTracker();
  generatePersonalizedNotifications();
}

function setWaterCupsDirect(cupIdx) {
  if (CompanionState.waterTracker.cups === cupIdx) {
    CompanionState.waterTracker.cups = cupIdx - 1;
  } else {
    CompanionState.waterTracker.cups = cupIdx;
  }
  saveWaterTracker();
  renderWaterTracker();
  generatePersonalizedNotifications();
}

function resetWaterTracker() {
  const isAr = CompanionState.lang === 'ar';
  if (confirm(isAr ? 'هل ترغبين في إعادة تعيين استهلاك الماء لهذا اليوم إلى صفر؟' : 'Would you like to reset today\'s water consumption to 0?')) {
    CompanionState.waterTracker.cups = 0;
    saveWaterTracker();
    renderWaterTracker();
    generatePersonalizedNotifications();
  }
}

function renderWaterTracker() {
  const tracker = CompanionState.waterTracker;
  const isAr = CompanionState.lang === 'ar';
  const target = tracker.targetCups || 12;
  const cups = tracker.cups || 0;
  const liters = (cups * 0.25).toFixed(1);
  const targetLiters = (target * 0.25).toFixed(1);
  const pct = Math.min(100, Math.round((cups / target) * 100));

  // Stage label
  const stageEl = document.getElementById('hydrationStageLabel');
  if (stageEl) {
    let stageNameEn = "Pregnant";
    let stageNameAr = "الحمل";
    if (CompanionState.profile.topic === 'breastfeeding') {
      stageNameEn = "Breastfeeding";
      stageNameAr = "الرضاعة الطبيعية";
    } else if (CompanionState.profile.topic === 'planning') {
      stageNameEn = "Planning";
      stageNameAr = "التخطيط للحمل";
    }
    stageEl.innerHTML = `
      <span class="lang-en">${stageNameEn} · Goal: ${target} Cups (${targetLiters}L)</span>
      <span class="lang-ar">مرحلة ${stageNameAr} · الهدف: ${target} كوب (${targetLiters} لتر)</span>
    `;
  }

  // Numbers & progress
  const countEl = document.getElementById('hydrationCupsCount');
  if (countEl) countEl.textContent = cups;

  const targetCupsEl = document.getElementById('hydrationTargetCups');
  if (targetCupsEl) targetCupsEl.textContent = target;

  const litersEl = document.getElementById('hydrationLitersLabel');
  if (litersEl) litersEl.textContent = `${liters} L / ${targetLiters} L`;

  const pctEl = document.getElementById('hydrationPercentLabel');
  if (pctEl) pctEl.textContent = `${pct}%`;

  const progressFill = document.getElementById('waterProgressFill');
  if (progressFill) progressFill.style.width = `${pct}%`;

  // Cups grid
  const grid = document.getElementById('waterCupsGrid');
  if (grid) {
    grid.innerHTML = '';
    for (let i = 1; i <= target; i++) {
      const btn = document.createElement('button');
      btn.className = `cup-btn ${i <= cups ? 'filled' : ''}`;
      btn.setAttribute('title', isAr ? `كوب ${i} (250 مل)` : `Cup ${i} (250ml)`);
      btn.innerHTML = `
        <span class="cup-icon">${i <= cups ? '🥤' : '💧'}</span>
        <span>${i}</span>
      `;
      btn.onclick = () => setWaterCupsDirect(i);
      grid.appendChild(btn);
    }
  }

  // Celebration badge
  const celebration = document.getElementById('waterGoalCelebration');
  if (celebration) {
    celebration.style.display = cups >= target ? 'flex' : 'none';
  }

  // Tip text from booklet
  const tipText = document.getElementById('hydrationTipText');
  if (tipText) {
    if (CompanionState.profile.topic === 'breastfeeding') {
      tipText.innerHTML = `
        <span class="lang-en"><strong>Booklet Golden Rule:</strong> Water is the #1 natural milk-booster (~16 cups / ~4L daily). Drink a large glass of water every single time you nurse your baby!</span>
        <span class="lang-ar"><strong>القاعدة الذهبية من الكتيب:</strong> الماء هو أهم مدر طبيعي لحليب الأم (~16 كوب / ~4 لتر يومياً). اشربي كوب ماء كبير مع كل رضعة لطفلكِ!</span>
      `;
    } else if (CompanionState.profile.topic === 'pregnant') {
      tipText.innerHTML = `
        <span class="lang-en"><strong>Booklet Hydration Rule:</strong> Drink ~3.0 Liters (~12 cups) daily to eliminate excess sodium, avoid 3rd-trimester leg/ankle edema, prevent UTIs, and relieve heartburn.</span>
        <span class="lang-ar"><strong>قاعدة الكتيب للحامل:</strong> شرب حوالي 3 لتر ماء (~12 كوب) يومياً لتخليص الجسم من الصوديوم الزائد، وتجنب تورم القدمين والكاحلين في الثلث الثالث، والوقاية من التهابات المسالك البولية وحموضة المعدة.</span>
      `;
    } else {
      tipText.innerHTML = `
        <span class="lang-en"><strong>Preconception Hydration:</strong> Drink at least 2.5 Liters (10 cups) daily to flush toxins and support optimal cellular hydration and healthy uterine blood flow.</span>
        <span class="lang-ar"><strong>الترطيب قبل الحمل:</strong> اشربي ما لا يقل عن 2.5 لتر (10 أكواب) يومياً لتنشيط الدورة الدموية وبناء بيئة خلوية مثالية لتهيئة الرحم لاستقبال الحمل.</span>
      `;
    }
  }
}

// ===================================================================
// PERSONALIZED OVERALL HEALTH NOTIFICATION ENGINE
// ===================================================================

function generatePersonalizedNotifications() {
  const stage = CompanionState.profile.topic;
  const age = parseInt(CompanionState.profile.age) || 28;
  const tri = CompanionState.profile.trimester || 2;
  const cups = CompanionState.waterTracker.cups;
  const targetCups = CompanionState.waterTracker.targetCups;
  const notifs = [];

  // 1. Stage-based clinical notifications from booklet
  if (stage === 'planning') {
    notifs.push({
      id: 'plan_folic',
      type: 'critical',
      tagEn: 'Preconception Essential',
      tagAr: 'ضرورة قبل الحمل',
      titleEn: 'Daily Folic Acid (400 mcg)',
      titleAr: 'حمض الفوليك اليومي (400 ميكروجرام)',
      descEn: 'Take 400 mcg of folic acid daily starting at least 1 month before conception to support healthy fetal neural tube development.',
      descAr: 'تناولي 400 ميكروجرام من حمض الفوليك يومياً قبل الحمل بشهر على الأقل للوقاية من تشوهات الأنبوب العصبي للجنين.',
      guideTab: 0
    });
    notifs.push({
      id: 'plan_pediamum',
      type: 'recommendation',
      tagEn: 'Pediamum® Preconception',
      tagAr: 'Pediamum® للتخطيط',
      titleEn: 'Saturating Maternal Nutrient Stores',
      titleAr: 'تشبع مخازن العناصر الغذائية للأم',
      descEn: 'Pediamum® delivers 27 essential vitamins and minerals, iron, and prebiotic dietary fiber to prepare your body for conception.',
      descAr: 'يوفر Pediamum® 27 فيتاميناً ومعدناً مع الحديد والألياف الحيوية لتهيئة جسمكِ وتغذية مخزونكِ لاستقبال الحمل.',
      guideTab: 3
    });
  } else if (stage === 'pregnant') {
    // General pregnancy safety: What to avoid
    notifs.push({
      id: 'preg_avoid',
      type: 'critical',
      tagEn: 'Clinical Safety · What to Avoid',
      tagAr: 'سلامة طبية · أطعمة للتجنب',
      titleEn: 'Strict Food Safety Precautions',
      titleAr: 'محاذير غذائية صارمة خلال الحمل',
      descEn: 'Avoid high-mercury predatory fish (shark, swordfish, king mackerel), unpasteurized dairy/soft cheeses, and undercooked meats/eggs to prevent listeria & toxoplasmosis.',
      descAr: 'تجنبي تماماً الأسماك المفترسة عالية الزئبق (القرش، سياف البحر، الماكريل الملكي)، والألبان والأجبان غير المبسترة، واللحوم والبيض غير المطهو جيداً لتفادي الليستيريا والتوكسوبلازما.',
      guideTab: 2
    });

    if (tri === 1) {
      notifs.push({
        id: 'preg_tri1_nausea',
        type: 'warning',
        tagEn: '1st Trimester · Weeks 1–12',
        tagAr: 'الثلث الأول · الأسابيع 1-12',
        titleEn: 'Managing Morning Nausea',
        titleAr: 'التعامل مع الغثيان الصباحي',
        descEn: 'Eat 5–6 small frequent meals. Keep dry whole-wheat crackers by your bed, sip ginger tea or cold water, and avoid greasy foods.',
        descAr: 'تناولي 5-6 وجبات صغيرة متفرقة. تناولي بسكويت القمح الجاف قبل النهوض من الفراش، واشربي منقوع الزنجبيل أو الماء البارد وتجنبي الأطعمة الدسمة.',
        guideTab: 0
      });
      notifs.push({
        id: 'preg_tri1_folic',
        type: 'recommendation',
        tagEn: 'Neural Formation',
        tagAr: 'تكوين الجهاز العصبي',
        titleEn: 'Continue Folic Acid Diligently',
        titleAr: 'الاستمرار في حمض الفوليك يومياً',
        descEn: 'Crucial for early embryonic cell division and spine development throughout your first trimester.',
        descAr: 'ضروري جداً لانقسام الخلايا وتطور النخاع الشوكي وعظام الجمجمة للجنين خلال الأشهر الثلاثة الأولى.',
        guideTab: 0
      });
    } else if (tri === 2) {
      notifs.push({
        id: 'preg_tri2_iron',
        type: 'recommendation',
        tagEn: '2nd Trimester · Weeks 13–27',
        tagAr: 'الثلث الثاني · الأسابيع 13-27',
        titleEn: 'Boost Iron with Vitamin C',
        titleAr: 'تعزيز امتصاص الحديد بفيتامين ج',
        descEn: 'Maternal blood volume expands rapidly! Pair iron-rich meals (spinach, lentils, lean meat) with citrus or bell peppers. Avoid tea and coffee with meals.',
        descAr: 'يزداد حجم دم الأم بشكل سريع! اجمعي بين مصادر الحديد (السبانخ، العدس، اللحوم) ومصادر فيتامين ج (الليمون، البرتقال، الفلفل). تجنبي الشاي والقهوة أثناء الوجبات.',
        guideTab: 0
      });
      notifs.push({
        id: 'preg_tri2_calcium',
        type: 'recommendation',
        tagEn: 'Fetal Skeletal Hardening',
        tagAr: 'بناء العظام والأسنان',
        titleEn: 'Calcium & Vitamin D3 for Baby\'s Bones',
        titleAr: 'الكالسيوم وفيتامين د3 لعظام طفلكِ',
        descEn: 'Baby\'s skeleton is ossifying. 2 servings of Pediamum® provide ideal bioavailable calcium and Vitamin D to prevent maternal bone demineralization.',
        descAr: 'يبدأ جنينكِ ببناء هيكله العظمي. يوفر كوبان من Pediamum® النسبة المثالية من الكالسيوم وفيتامين د3 لحماية عظام وأسنان الأم والطفل.',
        guideTab: 3
      });
    } else {
      // Trimester 3
      notifs.push({
        id: 'preg_tri3_protein',
        type: 'recommendation',
        tagEn: '3rd Trimester · Weeks 28–40',
        tagAr: 'الثلث الثالث · الأسابيع 28-40',
        titleEn: 'Target 80g Protein Daily',
        titleAr: 'استهدفي 80 جم بروتين يومياً',
        descEn: 'Accelerated fetal tissue and muscle growth. Include eggs, poultry, legumes, and Pediamum® maternal milk daily.',
        descAr: 'نمو متسارع لأنسجة وعضلات الجنين. احرصي على البيض والدواجن والبقوليات وحليب Pediamum® للأمومة يومياً.',
        guideTab: 0
      });
      notifs.push({
        id: 'preg_tri3_dha',
        type: 'recommendation',
        tagEn: '8th Month Brain Development',
        tagAr: 'الشهر الثامن · نمو الدماغ',
        titleEn: 'DHA for Baby\'s Brain & Retina',
        titleAr: 'حمض DHA لنمو دماغ وشبكية العين',
        descEn: 'In the 8th month, the fetal brain undergoes rapid neural expansion requiring ample omega-3 fatty acids and DHA.',
        descAr: 'في الشهر الثامن تتضاعف سرعة نمو خلايا المخ وشبكية العين لدى الجنين، مما يتطلب إمداداً وفيراً من أحماض الأوميجا 3 وDHA.',
        guideTab: 0
      });
      notifs.push({
        id: 'preg_tri3_dates',
        type: 'recommendation',
        tagEn: '9th Month Labor Preparation',
        tagAr: 'الشهر التاسع · تهيئة الولادة',
        titleEn: 'Dates for Natural Labor Readiness',
        titleAr: 'التمر لتسهيل الولادة الطبيعية',
        descEn: 'Consuming 3–6 dates daily in the 9th month supports spontaneous labor and cervical dilatation as highlighted in the booklet.',
        descAr: 'تناول 3 إلى 6 حبات تمر يومياً في الشهر التاسع يساعد على تليين عنق الرحم وتسهيل الولادة الطبيعية كما ورد في الكتيب.',
        guideTab: 0
      });
      notifs.push({
        id: 'preg_tri3_edema',
        type: 'warning',
        tagEn: 'Fluid Retention & Edema',
        tagAr: 'احتباس السوائل وتورم القدمين',
        titleEn: 'Combat 3rd-Trimester Swelling',
        titleAr: 'تقليل تورم القدمين والكاحلين',
        descEn: 'Drink ~3.0L water daily to flush excess sodium, reduce foot/ankle swelling, and prevent UTIs and constipation.',
        descAr: 'اشربي حوالي 3 لتر ماء يومياً لتخليص الجسم من الصوديوم الزائد، وتخفيف تورم القدمين، والوقاية من الإمساك والتهابات المسالك.',
        actionTab: 'calculate'
      });
    }
  } else if (stage === 'breastfeeding') {
    notifs.push({
      id: 'lact_water',
      type: 'hydration',
      tagEn: 'Breastfeeding Golden Rule',
      tagAr: 'القاعدة الذهبية للمرضع',
      titleEn: 'Drink a Large Glass with Every Feed',
      titleAr: 'اشربي كوب ماء كبير مع كل رضعة',
      descEn: 'Breast milk is 88% water. Target ~16 cups (~4.0 Liters) daily to maintain healthy milk production without dehydration.',
      descAr: 'حليب الأم يتكون من 88% ماء. استهدفي حوالي 16 كوب (~4.0 لتر) يومياً للحفاظ على تدفق الحليب وحمايتكِ من الجفاف.',
      actionTab: 'calculate'
    });
    notifs.push({
      id: 'lact_calories',
      type: 'recommendation',
      tagEn: '+500 kcal Daily Allowance',
      tagAr: '+500 سعرة حرارية يومياً',
      titleEn: 'Nourish Your Body for Milk Production',
      titleAr: 'تغذية الأم لتعويض طاقة الرضاعة',
      descEn: 'Lactation requires about 500 extra calories daily. Choose wholesome snacks: oatmeal, nuts, Greek yogurt, and Pediamum®.',
      descAr: 'تستهلك الرضاعة الطبيعية قرابة 500 سعرة حرارية إضافية يومياً. اختاري وجبات خفيفة مغذية كالشوفان والمكسرات والزبادي وPediamum®.',
      guideTab: 1
    });
    notifs.push({
      id: 'lact_galactagogues',
      type: 'recommendation',
      tagEn: '10 Natural Galactagogues',
      tagAr: '10 مدرات طبيعية للحليب',
      titleEn: 'Booklet Natural Milk Boosters',
      titleAr: 'مدرات الحليب الطبيعية من الكتيب',
      descEn: 'Incorporate: Water, Anise, Fenugreek, Arugula, Carrots, Beets, Oats, Cinnamon, Apricots, and quality Protein.',
      descAr: 'احرصي على: الماء، اليانسون، الحلبة، الجرجير، الجزر، البنجر، الشوفان، القرفة، المشمش، والبروتين الحيواني الصحي.',
      guideTab: 1
    });
    notifs.push({
      id: 'lact_colic_avoid',
      type: 'critical',
      tagEn: 'Infant Colic & Gas Avoidance',
      tagAr: 'محاذير مغص وغازات الرضيع',
      titleEn: 'Foods to Limit While Nursing',
      titleAr: 'أطعمة ينبغي تجنبها أثناء الرضاعة',
      descEn: 'Limit caffeine (transfers to milk and causes irritability/sleeplessness). Avoid gas-forming foods (raw onions, cabbage, cauliflower) right before feeds if baby has colic.',
      descAr: 'قللي الكافيين (ينتقل للرضيع ويسبب الأرق والمغص). تجنبي الخضار المسببة للغازات (الملفوف، القرنبيط، البصل النيء) قبل الرضاعة إن كان طفلكِ يعاني من المغص.',
      guideTab: 2
    });
  }

  // 2. Real-time Hydration progress notifications
  if (cups === 0) {
    notifs.push({
      id: 'hydr_morning',
      type: 'hydration',
      tagEn: 'Hydration Check',
      tagAr: 'تنبيه شرب الماء',
      titleEn: 'Start Today\'s Hydration Journey',
      titleAr: 'ابدئي ترطيب جسمكِ اليوم',
      descEn: `Log your first cups of water! Your daily target is ${targetCups} cups (${(targetCups*0.25).toFixed(1)}L).`,
      descAr: `سجلي أول أكواب الماء لهذا اليوم! هدفكِ اليومي هو ${targetCups} كوب (${(targetCups*0.25).toFixed(1)} لتر).`,
      actionTab: 'calculate'
    });
  } else if (cups < Math.floor(targetCups / 2)) {
    notifs.push({
      id: 'hydr_low',
      type: 'warning',
      tagEn: 'Hydration Alert',
      tagAr: 'تنبيه ترطيب',
      titleEn: `You've Logged ${cups} of ${targetCups} Cups`,
      titleAr: `لقد شربتِ ${cups} من أصل ${targetCups} كوب`,
      descEn: `Keep sipping water throughout your day to maintain electrolyte balance and prevent dehydration.`,
      descAr: `واصلي شرب الماء على فترات منتظمة للحفاظ على توازن السوائل وتجنب الإرهاق والجفاف.`,
      actionTab: 'calculate'
    });
  } else if (cups >= targetCups) {
    notifs.push({
      id: 'hydr_achieved',
      type: 'recommendation',
      tagEn: '🎉 Goal Reached',
      tagAr: '🎉 تم تحقيق الهدف',
      titleEn: `100% Daily Hydration Achieved!`,
      titleAr: `أحسنتِ! تم تحقيق 100% من هدف الماء اليومي`,
      descEn: `Outstanding job! You have logged ${cups} cups (${(cups*0.25).toFixed(1)}L), protecting both you and your baby.`,
      descAr: `عمل رائع! لقد سجلتِ ${cups} كوب (${(cups*0.25).toFixed(1)} لتر)، مما يوفر الحماية المثلى لصحتكِ وصحة طفلكِ.`,
      actionTab: 'calculate'
    });
  }

  // 3. Age-specific advice
  if (age >= 35) {
    notifs.push({
      id: 'age_senior',
      type: 'warning',
      tagEn: 'Age 35+ Healthcare Focus',
      tagAr: 'توصيات لسن 35 فما فوق',
      titleEn: 'Blood Pressure & Glucose Monitoring',
      titleAr: 'متابعة ضغط الدم وسكر الحمل',
      descEn: 'At age 35+, regular prenatal blood pressure checks, gestational diabetes screening, and bone-strengthening Calcium + Vitamin D3 are strongly recommended.',
      descAr: 'في سن 35 فما فوق، يوصى بالفحص الدوري لضغط الدم وسكر الحمل، ودعم كثافة العظام بالكالسيوم وفيتامين د3 والمغنيسيوم.'
    });
  }

  CompanionState.notifications = notifs;
  renderPersonalizedAlerts();
}

function renderPersonalizedAlerts() {
  const isAr = CompanionState.lang === 'ar';
  const notifs = CompanionState.notifications;
  const unreadNotifs = notifs.filter(n => !CompanionState.dismissedAlertIds.has(n.id));

  // 1. Update all badge counters
  document.querySelectorAll('.notifBadgeCount').forEach(badge => {
    badge.textContent = unreadNotifs.length;
    badge.style.display = unreadNotifs.length > 0 ? 'inline-flex' : 'none';
  });

  // 2. Render Top Home Alert Banner
  const homeBanner = document.getElementById('homeHealthAlertContainer');
  if (homeBanner) {
    if (unreadNotifs.length === 0) {
      homeBanner.innerHTML = '';
    } else {
      const topAlert = unreadNotifs[0];
      let icon = "🔔";
      if (topAlert.type === 'critical') icon = "⚠️";
      else if (topAlert.type === 'hydration') icon = "💧";
      else if (topAlert.type === 'warning') icon = "⚡";
      else if (topAlert.type === 'recommendation') icon = "✨";

      homeBanner.innerHTML = `
        <div class="health-alert-banner alert-${topAlert.type}">
          <div class="alert-banner-icon">${icon}</div>
          <div class="alert-banner-body">
            <div class="alert-banner-tag">${isAr ? topAlert.tagAr : topAlert.tagEn}</div>
            <div class="alert-banner-title">${isAr ? topAlert.titleAr : topAlert.titleEn}</div>
            <div class="alert-banner-text">${isAr ? topAlert.descAr : topAlert.descEn}</div>
            <div style="display:flex; flex-wrap:wrap; gap:8px; margin-top:8px;">
              <button onclick="openModal('notificationModal')" style="border:none; background:rgba(0,0,0,0.06); font-size:11px; font-weight:700; padding:4px 10px; border-radius:6px; cursor:pointer; color:var(--color-foreground);">
                ${isAr ? `عرض كل التنبيهات (${unreadNotifs.length})` : `View all alerts (${unreadNotifs.length})`}
              </button>
              ${topAlert.guideTab !== undefined ? `
                <button onclick="openBookletGuideTab(${topAlert.guideTab})" style="border:1px solid rgba(0,0,0,0.12); background:var(--color-surface); font-size:11px; font-weight:700; padding:4px 10px; border-radius:6px; cursor:pointer; color:var(--color-primary);">
                  ${topAlert.guideTab === 2 ? (isAr ? '🚫 عرض المحاذير ↗' : '🚫 View Foods to Avoid ↗') : (isAr ? '📖 فتح الدليل ↗' : '📖 View Guide ↗')}
                </button>
              ` : ''}
              ${topAlert.actionTab ? `
                <button onclick="switchTab('${topAlert.actionTab}')" style="border:1px solid rgba(0,0,0,0.12); background:var(--color-surface); font-size:11px; font-weight:700; padding:4px 10px; border-radius:6px; cursor:pointer; color:var(--color-primary);">
                  ${isAr ? '💧 فتح مسجل الماء ↗' : '💧 Open Water Tracker ↗'}
                </button>
              ` : ''}
            </div>
          </div>
          <button class="alert-banner-close" onclick="dismissAlert('${topAlert.id}')" title="Dismiss">✕</button>
        </div>
      `;
    }
  }

  // 3. Render Modal Notifications List
  const modalContainer = document.getElementById('modalNotificationsContainer');
  if (modalContainer) {
    if (notifs.length === 0) {
      modalContainer.innerHTML = `<p class="helper-text">${isAr ? 'لا توجد تنبيهات حالية.' : 'No active alerts at this moment.'}</p>`;
    } else {
      modalContainer.innerHTML = notifs.map(n => {
        const isDismissed = CompanionState.dismissedAlertIds.has(n.id);
        let icon = "🔔";
        if (n.type === 'critical') icon = "⚠️";
        else if (n.type === 'hydration') icon = "💧";
        else if (n.type === 'warning') icon = "⚡";
        else if (n.type === 'recommendation') icon = "✨";

        return `
          <div class="notif-card ${isDismissed ? '' : 'unread'}">
            <div class="notif-icon-wrap notif-icon-${n.type}">
              ${icon}
            </div>
            <div class="notif-content">
              <div class="notif-meta-row">
                <span class="notif-tag">${isAr ? n.tagAr : n.tagEn}</span>
                <span class="notif-time">${isDismissed ? (isAr ? 'مقروء' : 'Read') : (isAr ? 'جديد' : 'New')}</span>
              </div>
              <div class="notif-title">${isAr ? n.titleAr : n.titleEn}</div>
              <div class="notif-desc">${isAr ? n.descAr : n.descEn}</div>
              ${n.guideTab !== undefined ? `
                <div style="margin-top:6px;">
                  <button onclick="closeModal('notificationModal'); openBookletGuideTab(${n.guideTab});" style="background:var(--color-surface); border:1px solid var(--color-border); border-radius:6px; padding:3px 9px; font-size:11px; font-weight:700; color:var(--color-primary); cursor:pointer;">
                    ${n.guideTab === 2 ? (isAr ? '🚫 عرض قسم الأطعمة للتجنب ↗' : '🚫 Open Foods to Avoid Section ↗') : (isAr ? '📖 فتح الدليل التغذوي ↗' : '📖 Open Nutrition Guide ↗')}
                  </button>
                </div>
              ` : ''}
              ${n.actionTab ? `
                <div style="margin-top:6px;">
                  <button onclick="closeModal('notificationModal'); switchTab('${n.actionTab}');" style="background:var(--color-surface); border:1px solid var(--color-border); border-radius:6px; padding:3px 9px; font-size:11px; font-weight:700; color:var(--color-primary); cursor:pointer;">
                    ${isAr ? '💧 فتح مسجل استهلاك الماء ↗' : '💧 Open Hydration Tracker ↗'}
                  </button>
                </div>
              ` : ''}
            </div>
            ${!isDismissed ? `<button onclick="dismissAlert('${n.id}')" style="border:none; background:none; color:#94A3B8; cursor:pointer; font-size:16px;" title="Dismiss">✕</button>` : ''}
          </div>
        `;
      }).join('');
    }
  }

  // 4. Render Profile Stage Badges in Modal
  const modalBadges = document.getElementById('modalProfileStageBadges');
  if (modalBadges) {
    let stageName = CompanionState.profile.topic === 'breastfeeding' ? (isAr ? '🤱 الرضاعة الطبيعية' : '🤱 Breastfeeding') :
                    CompanionState.profile.topic === 'planning' ? (isAr ? '🌸 التخطيط للحمل' : '🌸 Planning') :
                    (isAr ? `🤰 الحمل (الثلث ${CompanionState.profile.trimester || 2})` : `🤰 Pregnancy (Trimester ${CompanionState.profile.trimester || 2})`);
    
    modalBadges.innerHTML = `
      <span style="font-size:11px; font-weight:700; background:var(--color-primary-soft); color:var(--color-primary); padding:3px 8px; border-radius:6px;">
        ${stageName}
      </span>
      <span style="font-size:11px; font-weight:700; background:#E0F2FE; color:#0369A1; padding:3px 8px; border-radius:6px;">
        ${isAr ? `العمر: ${CompanionState.profile.age || 28} سنة` : `Age: ${CompanionState.profile.age || 28} yrs`}
      </span>
      <span style="font-size:11px; font-weight:700; background:#DCFCE7; color:#15803D; padding:3px 8px; border-radius:6px;">
        ${isAr ? `الماء: ${CompanionState.waterTracker.cups}/${CompanionState.waterTracker.targetCups} كوب` : `Water: ${CompanionState.waterTracker.cups}/${CompanionState.waterTracker.targetCups} cups`}
      </span>
    `;
  }
}

function dismissAlert(id) {
  CompanionState.dismissedAlertIds.add(id);
  renderPersonalizedAlerts();
}

function markAllNotificationsRead() {
  CompanionState.notifications.forEach(n => CompanionState.dismissedAlertIds.add(n.id));
  renderPersonalizedAlerts();
}

// ===================================================================
// EXTENDED PROFILE & BMI HANDLERS
// ===================================================================

function selectTrimester(tri) {
  CompanionState.profile.trimester = tri;
  document.querySelectorAll('.trimester-pill').forEach(pill => {
    if (parseInt(pill.getAttribute('data-tri')) === tri) {
      pill.classList.add('selected');
    } else {
      pill.classList.remove('selected');
    }
  });
  saveProfileDetails(false);
  generatePersonalizedNotifications();
}

function calculateBmiGuidance() {
  const w = parseFloat(CompanionState.profile.weight);
  const h = parseFloat(CompanionState.profile.height);
  const fb = document.getElementById('profileBmiFeedback');
  if (!fb) return;

  if (w > 30 && h > 100) {
    const bmi = w / ((h / 100) * (h / 100));
    const bmiRounded = bmi.toFixed(1);
    let categoryEn = "";
    let categoryAr = "";
    let targetGainEn = "";
    let targetGainAr = "";

    if (bmi < 18.5) {
      categoryEn = "Underweight";
      categoryAr = "نقص في الوزن";
      targetGainEn = "Recommended pregnancy weight gain: 12.5 – 18.0 kg";
      targetGainAr = "الزيادة الموصى بها في وزن الحمل: 12.5 - 18 كجم";
    } else if (bmi <= 24.9) {
      categoryEn = "Normal Weight (Optimal Preconception)";
      categoryAr = "وزن طبيعي ومثالي";
      targetGainEn = "Recommended pregnancy weight gain: 11.5 – 16.0 kg";
      targetGainAr = "الزيادة الموصى بها في وزن الحمل: 11.5 - 16 كجم";
    } else if (bmi <= 29.9) {
      categoryEn = "Overweight";
      categoryAr = "وزن زائد";
      targetGainEn = "Recommended pregnancy weight gain: 7.0 – 11.5 kg";
      targetGainAr = "الزيادة الموصى بها في وزن الحمل: 7 - 11.5 كجم";
    } else {
      categoryEn = "Obesity";
      categoryAr = "سمنة";
      targetGainEn = "Recommended pregnancy weight gain: 5.0 – 9.0 kg";
      targetGainAr = "الزيادة الموصى بها في وزن الحمل: 5 - 9 كجم";
    }

    fb.style.display = 'block';
    fb.innerHTML = `
      <div><strong>BMI: ${bmiRounded} (${CompanionState.lang === 'ar' ? categoryAr : categoryEn})</strong></div>
      <div style="margin-top:2px;">${CompanionState.lang === 'ar' ? targetGainAr : targetGainEn}</div>
    `;
  } else {
    fb.style.display = 'none';
  }
}

// Save Profile Details
function saveProfileDetails(showAlert = true) {
  const nameInput = document.getElementById('profileNameInput');
  const ageInput = document.getElementById('profileAgeInput');
  const weightInput = document.getElementById('profileWeightInput');
  const heightInput = document.getElementById('profileHeightInput');

  if (nameInput) CompanionState.profile.name = nameInput.value;
  if (ageInput) CompanionState.profile.age = ageInput.value;
  if (weightInput) CompanionState.profile.weight = weightInput.value;
  if (heightInput) CompanionState.profile.height = heightInput.value;

  try {
    localStorage.setItem('pediamum_profile', JSON.stringify(CompanionState.profile));
  } catch(e) {}

  calculateBmiGuidance();
  CompanionState.waterTracker.targetCups = calculateWaterTarget();
  saveWaterTracker();
  renderWaterTracker();
  generatePersonalizedNotifications();

  if (showAlert) {
    alert(CompanionState.lang === 'ar' ? 'تم حفظ بيانات الملف وتحديث التوصيات الصحية وهدف الماء اليومي بنجاح!' : 'Profile saved and personalized health guidance updated successfully!');
  }
}

// Select Profile Topic Pill
function selectProfileTopic(topicId) {
  CompanionState.profile.topic = topicId;
  document.querySelectorAll('.profile-topic-pill').forEach(pill => {
    if (pill.getAttribute('data-topic') === topicId) {
      pill.style.backgroundColor = 'var(--color-foreground)';
      pill.style.color = '#FFFFFF';
      pill.style.borderColor = 'var(--color-foreground)';
    } else {
      pill.style.backgroundColor = 'var(--color-surface)';
      pill.style.color = 'var(--color-foreground)';
      pill.style.borderColor = 'var(--color-border)';
    }
  });

  // Show/hide trimester selector
  const triWrap = document.getElementById('profileTrimesterWrap');
  if (triWrap) {
    triWrap.style.display = topicId === 'pregnant' ? 'flex' : 'none';
  }

  // Update water goal dynamically based on stage
  CompanionState.waterTracker.targetCups = calculateWaterTarget();
  saveWaterTracker();
  renderWaterTracker();
  generatePersonalizedNotifications();
}

// Clear Local Demo Data
function clearDemoData() {
  const isAr = CompanionState.lang === 'ar';
  const confirmed = confirm(isAr ? 'هل أنتِ متأكدة من رغبتكِ في مسح جميع البيانات وسجل الوجبات وتتبع الماء محلياً؟' : 'Are you sure you want to clear all locally saved meals, water logs, and profile data?');
  if (confirmed) {
    try {
      localStorage.removeItem('pediamum_saved_meals');
      localStorage.removeItem('pediamum_profile');
      localStorage.removeItem('pediamum_water');
    } catch(e) {}
    CompanionState.savedMeals = [];
    CompanionState.profile = { name: '', age: '28', topic: 'pregnant', trimester: 2, weight: '', height: '' };
    CompanionState.waterTracker = { date: getTodayDateString(), cups: 0, targetCups: 12 };
    CompanionState.dismissedAlertIds.clear();

    const nameInput = document.getElementById('profileNameInput');
    const ageInput = document.getElementById('profileAgeInput');
    const weightInput = document.getElementById('profileWeightInput');
    const heightInput = document.getElementById('profileHeightInput');
    if (nameInput) nameInput.value = '';
    if (ageInput) ageInput.value = '';
    if (weightInput) weightInput.value = '';
    if (heightInput) heightInput.value = '';

    renderSavedMealsList();
    renderWaterTracker();
    generatePersonalizedNotifications();
    calculateBmiGuidance();
    alert(isAr ? 'تم مسح البيانات المحلية بنجاح.' : 'Local demo data cleared successfully.');
  }
}

// Modal Helpers
function openModal(modalId, tabIdx) {
  const el = document.getElementById(modalId);
  if (el) el.classList.add('open');
  if (modalId === 'bookletGuideModal' && typeof tabIdx === 'number') {
    selectGuideTab(tabIdx);
  }
}

function openBookletGuideTab(tabIdx = 0) {
  openModal('bookletGuideModal', tabIdx);
  selectGuideTab(tabIdx);
  const modal = document.getElementById('bookletGuideModal');
  if (modal) {
    const content = modal.querySelector('.modal-content');
    if (content) content.scrollTop = 0;
  }
}

function closeModal(modalId) {
  const el = document.getElementById(modalId);
  if (el) el.classList.remove('open');
}

// Recipe Tabs Switcher
function selectRecipeTab(idx) {
  document.querySelectorAll('.recipe-tab-pill').forEach((pill, i) => {
    if (i === idx) pill.classList.add('active');
    else pill.classList.remove('active');
  });
  document.querySelectorAll('.recipe-pane').forEach((pane, i) => {
    if (i === idx) pane.classList.add('active');
    else pane.classList.remove('active');
  });
}

// Booklet Guide Tab Switcher
function selectGuideTab(idx) {
  document.querySelectorAll('.guide-tab-pill').forEach((pill, i) => {
    if (i === idx) pill.classList.add('active');
    else pill.classList.remove('active');
  });
  document.querySelectorAll('.guide-pane').forEach((pane, i) => {
    if (i === idx) pane.classList.add('active');
    else pane.classList.remove('active');
  });
}

// Initialize on Load
document.addEventListener('DOMContentLoaded', () => {
  // Load saved local data
  try {
    const saved = localStorage.getItem('pediamum_saved_meals');
    if (saved) CompanionState.savedMeals = JSON.parse(saved);

    const savedProf = localStorage.getItem('pediamum_profile');
    if (savedProf) {
      CompanionState.profile = Object.assign(CompanionState.profile, JSON.parse(savedProf));
      const nameInput = document.getElementById('profileNameInput');
      const ageInput = document.getElementById('profileAgeInput');
      const weightInput = document.getElementById('profileWeightInput');
      const heightInput = document.getElementById('profileHeightInput');
      if (nameInput) nameInput.value = CompanionState.profile.name || '';
      if (ageInput) ageInput.value = CompanionState.profile.age || '';
      if (weightInput) weightInput.value = CompanionState.profile.weight || '';
      if (heightInput) heightInput.value = CompanionState.profile.height || '';
    }
  } catch(e) {}

  // Apply profile topic and trimester UI
  selectProfileTopic(CompanionState.profile.topic || 'pregnant');
  selectTrimester(CompanionState.profile.trimester || 2);

  // Initialize Water Tracker & Notifications
  initWaterTracker();
  generatePersonalizedNotifications();
  calculateBmiGuidance();

  // Initial category render
  renderCategoryPills();
  renderSavedMealsList();
  calculateTotalCalories();

  // Setup tab clicks
  document.querySelectorAll('.tab-item').forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      const tab = item.getAttribute('data-tab');
      if (tab) switchTab(tab);
    });
  });

  // URL query parameter support for language (e.g. ?lang=ar)
  const urlParams = new URLSearchParams(window.location.search);
  if (urlParams.get('lang') === 'ar') {
    applyLanguage('ar');
  }

  // Route-aware active tab: checks URL parameter ?tab=..., hash #/..., or pathname
  const path = window.location.pathname.toLowerCase();
  const hash = window.location.hash.toLowerCase().replace('#/', '').replace('#', '');
  const tabParam = urlParams.get('tab');
  const target = tabParam || hash;

  if (target === 'explore' || path.includes('explore')) {
    switchTab('explore');
  } else if (target === 'profile' || path.includes('profile')) {
    switchTab('profile');
  } else if (target === 'home' || path.includes('home')) {
    switchTab('home');
  } else {
    switchTab('calculate');
  }

  // URL query parameter support for direct modal & guide tab deep links
  if (urlParams.get('guide') === 'avoid' || urlParams.get('guide') === '2') {
    openBookletGuideTab(2);
  } else if (urlParams.get('modal')) {
    openModal(urlParams.get('modal'));
  }
});

